There are a total of **5** squares in the image. 
