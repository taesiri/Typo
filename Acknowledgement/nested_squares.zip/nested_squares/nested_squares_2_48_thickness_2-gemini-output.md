There are **two** squares in the image. 
- One smaller square inside
- One larger square forming the outer boundary. 
