There are **2** squares in the image. 
