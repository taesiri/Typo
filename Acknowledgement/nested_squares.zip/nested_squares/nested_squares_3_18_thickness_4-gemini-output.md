There are **3** squares in the image. 
