There are **two** squares in the image. 
