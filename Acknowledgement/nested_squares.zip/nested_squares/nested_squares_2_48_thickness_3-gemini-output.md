There are **2** squares in the image. 
* One smaller square inside.
* One larger square forming the outer boundary. 
