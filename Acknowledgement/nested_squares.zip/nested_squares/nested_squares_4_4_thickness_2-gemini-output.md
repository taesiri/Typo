There are **4** squares in the image. 
