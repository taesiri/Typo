There are **three** squares in the image. 
