There are **5** squares in the image. 
